package using_XML_for_url;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

@SuppressWarnings("serial")
public class Display_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("User: "+req.getParameter("name"));
		
		pw.println("<br>====Servlet Context====");
		ServletContext sct=req.getServletContext();
		pw.println("<br>Servlet Info: "+sct.getServerInfo());
		pw.println("<br>Context Value: "+sct.getInitParameter("a"));
		
		pw.println("<br>====Servlet Config====");
		ServletConfig scg=this.getServletConfig();
		pw.println("<br>Servlet Name: "+scg.getServletName());
		pw.println("<br>Config Value: "+scg.getInitParameter("b"));
	}
}
