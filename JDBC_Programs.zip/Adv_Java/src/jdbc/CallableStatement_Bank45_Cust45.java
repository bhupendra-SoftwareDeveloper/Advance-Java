package jdbc;
import java.sql.*;
import java.util.*;
public class CallableStatement_Bank45_Cust45
{
	public static void main(String[] args)
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			CallableStatement cs=con.prepareCall("{call CREATEACCOUNT(?,?,?,?,?,?,?)}");
			
			System.out.println("Enter Account Number: ");
			long acc_no=Long.parseLong(sc.nextLine());
			System.out.println("Enter Account Holder Name: ");
			String acc_name=sc.nextLine();
			System.out.println("Enter Balance: ");
			float balance=Float.parseFloat(sc.nextLine());
			System.out.println("Enter Account Type: ");
			String acc_type=sc.nextLine();
			System.out.println("Enter Address: ");
			String address=sc.nextLine();
			System.out.println("Enter E-mail: ");
			String email=sc.nextLine();
			System.out.println("Enter Phone Number: ");
			long phone_no=sc.nextLong();
			
			cs.setLong(1, acc_no);
			cs.setString(2, acc_name);
			cs.setFloat(3, balance);
			cs.setString(4, acc_type);
			cs.setString(5, address);
			cs.setString(6, email);
			cs.setLong(7, phone_no);
			cs.execute();
			System.out.println("Procedure Executed Successfully...");
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
