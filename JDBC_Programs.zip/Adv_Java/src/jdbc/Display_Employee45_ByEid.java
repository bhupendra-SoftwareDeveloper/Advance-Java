package jdbc;
import java.util.*;
import java.sql.*;
public class Display_Employee45_ByEid
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter Employee Id which you want to search: ");
			String eid2=sc.nextLine();
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM EMPLOYEE45 WHERE EID='"+eid2+"'");
			int c=0;
			while(rs.next())
			{
				c++;
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+
				rs.getFloat(4)+"\t"+rs.getFloat(5));
			}
			if(c<1)System.out.println("No Data Found...Enter Valid Data");
			con.close();
			sc.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
