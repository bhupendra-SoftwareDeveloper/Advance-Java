package jdbc;
import java.sql.*;
import java.util.*;
public class UserReg45_Register
{

	public static void main(String[] args)
	{
		int c=0;
		Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("==============Welcome==============");
			while(true)
			{
				c=0;
				System.out.println(" 1.Registration \n 2.Login \n 3.Exit");
				int choice=sc.nextInt();
				sc.nextLine();
				
				Connection con=DriverManager.getConnection
				("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
				PreparedStatement ps=con.prepareStatement("insert into userreg45 values(?,?,?,?,?,?,?)");
				PreparedStatement ps2=con.prepareStatement("select * from userreg45 where uname=? and pword=?");
				
				switch(choice)
				{
				case 1:
					System.out.println("Enter UserName: ");
					String uname=sc.nextLine();
					System.out.println("Enter Password: ");
					String pword=sc.nextLine();
					System.out.println("Enter First Name: ");
					String fname=sc.nextLine();
					System.out.println("Enter Last Name: ");
					String lname=sc.nextLine();
					System.out.println("Enter Address: ");
					String address=sc.nextLine();
					System.out.println("Enter E-mail: ");
					String email=sc.nextLine();
					System.out.println("Enter Phone No: ");
					String phone_no=sc.nextLine();
				
					ps.setString(1, uname);
					ps.setString(2, pword);
					ps.setString(3, fname);
					ps.setString(4, lname);
					ps.setString(5, address);
					ps.setString(6, email);
					ps.setString(7, phone_no);
				
					int k=ps.executeUpdate();
					if(k==1)System.out.println("Registration Done...");
					break;
				case 2:
					System.out.println("Enter UserName: ");
					String uname2=sc.nextLine();
					System.out.println("Enter Password: ");
					String pword2=sc.nextLine();
					
					ps2.setString(1,uname2);
					ps2.setString(2, pword2);
					
					ResultSet rs=ps2.executeQuery();
					while(rs.next())
					{
						c++;
						System.out.println("Welcome "+rs.getString(3)+"");
					}
					if(c<1)System.out.println("Invalid UserName or Password...");
					break;
				case 3:
					System.out.println("Visit Again...");
					System.exit(0);
					break;
					
				default :System.out.println("Invalid Selection...");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		sc.close();
	}

}
