package jdbc;
import java.sql.*;
public class Batch_Processing_Using_Statement
{

	public static void main(String[] args)
	{
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			Statement stmt=con.createStatement();
			stmt.addBatch("INSERT INTO PRODUCT45 VALUES('CH11','CHARGER',830,5)");
			stmt.addBatch("INSERT INTO PRODUCT45 VALUES('USB11','USB',700,6)");
			stmt.addBatch("INSERT INTO PRODUCT45 VALUES('MF11','MOBILE FAN',830,7)");
			int[] k=stmt.executeBatch();
			for(int i=0;i<k.length;i++)System.out.println("Data Updated...");
			stmt.clearBatch();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
