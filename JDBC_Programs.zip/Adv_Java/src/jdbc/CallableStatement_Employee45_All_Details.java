package jdbc;
import java.sql.*;
import java.util.*;
public class CallableStatement_Employee45_All_Details
{

	public static void main(String[] args)
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			CallableStatement cs=con.prepareCall("{call EMPDETAILS45(?,?,?,?,?,?,?,?,?,?,?)}");
			
			System.out.println("Enter EmployeeId: ");
			String eid=sc.nextLine();
			System.out.println("Enter Employee Name: ");
			String ename=sc.nextLine();
			System.out.println("Enter Employee Designation: ");
			String edesg=sc.nextLine();
			System.out.println("Enter Employee House Number: ");
			String house_no=sc.nextLine();
			System.out.println("Enter Employee Street Number: ");
			String street_no=sc.nextLine();
			System.out.println("Enter Employee City: ");
			String city=sc.nextLine();
			System.out.println("Enter Employee Pincode: ");
			long pincode=Integer.parseInt(sc.nextLine());
			System.out.println("Enter Employee E-mail: ");
			String email=sc.nextLine();
			System.out.println("Enter Employee Phone Number: ");
			long phone_no=Long.parseLong(sc.nextLine());
			System.out.println("Enter Employee Basic Salary: ");
			float basic_salary=sc.nextFloat();
			
			float total_salary=(basic_salary+((basic_salary*(0.93f))+(basic_salary*(0.63f))));
			
			cs.setString(1, eid);
			cs.setString(2, ename);
			cs.setString(3, edesg);
			cs.setString(4, house_no);
			cs.setString(5, street_no);
			cs.setString(6, city);
			cs.setLong(7, pincode);
			cs.setString(8, email);
			cs.setLong(9, phone_no);
			cs.setFloat(10, basic_salary);
			cs.setFloat(11, total_salary);
			
			cs.execute();
			System.out.println("Procedure Executed Successfully...");
			
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
