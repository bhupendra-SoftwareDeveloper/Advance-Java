package jdbc;
import java.util.*;
import java.sql.*;
public class Function_Retrive_Balance_By_AccNo 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			CallableStatement cs=con.prepareCall("{call ? := RETRIVEBALANCE(?)}");
			
			System.out.println("Enter Account Number: ");
			long acc=sc.nextLong();
			
			cs.registerOutParameter(1,Types.FLOAT);
			cs.setLong(2, acc);
			cs.execute();
			
			System.out.println("Account Number: "+acc);
			System.out.println("Balance: "+cs.getFloat(1));
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
