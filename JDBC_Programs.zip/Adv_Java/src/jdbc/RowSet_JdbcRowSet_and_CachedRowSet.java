package jdbc;
import javax.sql.rowset.*;
import java.util.*;

public class RowSet_JdbcRowSet_and_CachedRowSet
{

	public static void main(String[] args)
	{
		try
		{
			Scanner s=new Scanner(System.in);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			RowSetFactory rsf=RowSetProvider.newFactory();
			System.out.println("=====Choice=====");
			System.out.println("1.JdbcRowSet \n2.CachedRowSet");
			System.out.println("Enter Your Choice: ");
			int c=s.nextInt();
			
			switch(c)
			{
				case 1:
					JdbcRowSet jrs=rsf.createJdbcRowSet();
					jrs.setUrl("jdbc:oracle:thin:@localhost:1521:XE");
					jrs.setUsername("C##PRACTICE");
					jrs.setPassword("ORACLE");
					jrs.setCommand("SELECT * FROM BANK45");
					jrs.execute();
					System.out.println("-----Forward Direction-----");
					while(jrs.next())
					{
						System.out.println(jrs.getInt(1)+"\t"+jrs.getString(2)+"\t"+jrs.getFloat(3)+"\t"+jrs.getString(4));
					}
					
					System.out.println();
					System.out.println("-----Backward Direction-----");
					while(jrs.previous())
					{
						System.out.println(jrs.getInt(1)+"\t"+jrs.getString(2)+"\t"+jrs.getFloat(3)+"\t"+jrs.getString(4));
					}
					break;
					
				case 2:
					CachedRowSet crs=rsf.createCachedRowSet();
					crs.setUrl("jdbc:oracle:thin:@localhost:1521:XE");
					crs.setUsername("C##PRACTICE");
					crs.setPassword("ORACLE");
					crs.setCommand("SELECT * FROM EMPLOYEE45");
					crs.execute();
					while(crs.next())
					{
						System.out.println(crs.getString(1)+"\t"+crs.getString(2)+"\t"+crs.getString(3)+"\t"+
								crs.getFloat(4)+"\t"+crs.getFloat(5));
					}
					break;
					
				default :
					System.out.println("Invalid Selection!!!");
			}
			s.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
