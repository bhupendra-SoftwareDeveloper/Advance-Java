package jdbc;
import java.sql.*;
import java.util.*;
public class Insert_INTO_Employee45
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter Employee Id: ");
			String eid=sc.nextLine();
			System.out.println("Enter Employee Name: ");
			String ename=sc.nextLine();
			System.out.println("Enter Employee Designation: ");
			String edesign=sc.nextLine();
			System.out.println("Enter Employee Basic Salary: ");
			float bsal=sc.nextFloat();
			float hra=bsal*93/100;
			float da=bsal*63/100;
			float totalsal=bsal+hra+da;
			
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			Statement stmt=con.createStatement();
			int k=stmt.executeUpdate("INSERT INTO EMPLOYEE45 VALUES('"+eid+"','"+ename+"','"+edesign+"','"+bsal+"','"+totalsal+"')");
			
			if(k>0)System.out.println("Employee details inserted Successfully...");
			sc.close();
			con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
