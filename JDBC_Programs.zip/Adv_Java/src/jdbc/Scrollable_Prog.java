package jdbc;
import java.sql.*;
public class Scrollable_Prog
{

	public static void main(String[] args)
	{
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			Statement st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs=st.executeQuery("select * from product45");
			rs.afterLast();
			while(rs.previous())
			{
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t"+rs.getInt(4));
			}
			
			System.out.println();
			System.out.println("---------Using Prepared Statement---------");
			PreparedStatement ps=con.prepareStatement("select * from bank45",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs1=ps.executeQuery();
			rs1.afterLast();
			while(rs1.previous())
			{
				System.out.println(rs1.getInt(1)+"\t"+rs1.getString(2)+"\t"+rs1.getFloat(3)+"\t"+rs1.getString(4));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
