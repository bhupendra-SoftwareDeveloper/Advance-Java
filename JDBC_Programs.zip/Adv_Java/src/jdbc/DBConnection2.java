package jdbc;
import java.sql.*;
import java.util.*;
public class DBConnection2 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter Pcode: ");
			String pcode=sc.nextLine();
			System.out.println("Enter Pname: ");
			String pname=sc.nextLine();
			System.out.println("Enter Pprice: ");
			String pprice=sc.nextLine();
			System.out.println("Enter Pqty: ");
			String pqty=sc.nextLine();
			
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			Statement stmt=con.createStatement();
			int k=stmt.executeUpdate("INSERT INTO PRODUCT45 VALUES('"+pcode+"','"+pname+"','"+pprice+"','"+pqty+"')");
			
			if(k>0) System.out.println("Product detailes inserted Successfully...");
			con.close();
			sc.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
