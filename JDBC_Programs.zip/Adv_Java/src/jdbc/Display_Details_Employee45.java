package jdbc;
import java.sql.*;
public class Display_Details_Employee45 
{
	public static void main(String[] args)
	{
		int c=0;
		try {
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM Employee45");
			
			while(rs.next())
			{
				c++;
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+
				rs.getFloat(4)+"\t"+rs.getFloat(5));
			}
			if(c<1)System.out.println("No data available...");
			con.close();
			rs.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
