package jdbc;
import java.sql.*;
public class Display_All_AccountNumber
{

	public static void main(String[] args)
	{
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			PreparedStatement ps=con.prepareStatement("SELECT ACC_NO FROM BANK45");
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
				System.out.println(rs.getLong(1));
			
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
