package jdbc;
import java.sql.*;
public class DBConnection1
{
	public static void main(String[] args)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from PRODUCT45");
		
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t"+rs.getInt(4));
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
