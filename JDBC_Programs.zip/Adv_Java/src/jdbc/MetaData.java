package jdbc;
import java.sql.*;
import javax.sql.RowSetMetaData;
import javax.sql.rowset.*;
public class MetaData
{

	public static void main(String[] args)
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			DatabaseMetaData dbmd=con.getMetaData();
			System.out.println("Driver Version: "+dbmd.getDriverMajorVersion());
			
			PreparedStatement ps=con.prepareStatement("SELECT * FROM BOOK45 WHERE BCODE=?");
			ps.setString(1,"");
			
			ParameterMetaData pmd=ps.getParameterMetaData();
			System.out.println("Count: "+pmd.getParameterCount());
			
			ResultSet rs=ps.executeQuery();
			ResultSetMetaData rsmd=rs.getMetaData();
			System.out.println("Column Count: "+rsmd.getColumnCount());
			
			JdbcRowSet jrs=RowSetProvider.newFactory().createJdbcRowSet();
			jrs.setUrl("jdbc:oracle:thin:@localhost:1521:XE");
			jrs.setUsername("C##PRACTICE");
			jrs.setPassword("ORACLE");
			jrs.setCommand("SELECT * FROM PRODUCT45");
			jrs.execute();
			
			RowSetMetaData rsmd2=(RowSetMetaData)jrs.getMetaData();
			System.out.println(rsmd2.getColumnCount());
			con.close();
			jrs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
