package jdbc;
import java.sql.*;
public class Batch_Processing_Using_PreparedStatement 
{

	public static void main(String[] args) 
	{
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			PreparedStatement ps=con.prepareStatement("INSERT INTO PRODUCT45 VALUES(?,?,?,?)");
			
			ps.setString(1,"P11");
			ps.setString(2,"PEN");
			ps.setFloat(3,25);
			ps.setInt(4, 120);
			ps.addBatch();
			
			ps.setString(1,"ER11");
			ps.setString(2,"EARPHONE");
			ps.setFloat(3,120);
			ps.setInt(4,210);
			ps.addBatch();
			
			int[] k=ps.executeBatch();
			for(int i=0;i<k.length;i++)System.out.println("Data Updated...");
			ps.clearBatch();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
