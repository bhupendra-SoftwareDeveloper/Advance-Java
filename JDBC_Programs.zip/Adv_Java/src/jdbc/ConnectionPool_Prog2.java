package jdbc;
import java.sql.*;
public class ConnectionPool_Prog2
{
	public static void main(String[] args)
	{
	
		try
		{
				ConnectionPool_Prog1 cp = new ConnectionPool_Prog1
					("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
					cp.createConnection();
					System.out.println("Pool Size: "+cp.v.size());
					Connection con = cp.useConnection();
					System.out.println("User using : "+con);
					System.out.println("Pool Size: "+cp.v.size());
					cp.returnConnection(con);
					System.out.println("Pool Size: "+cp.v.size());
					System.out.println("====Display the Connection from Pool====");
					cp.v.forEach((k)->System.out.println(k));
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}	