package jdbc;
import java.sql.*;
import java.util.*;

public class Book45_All_Operation
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int count=0,count2=0;
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			PreparedStatement ps1=con.prepareStatement("INSERT INTO BOOK45 VALUES(?,?,?,?,?)");
			PreparedStatement ps2=con.prepareStatement("SELECT * FROM BOOK45");
			PreparedStatement ps3=con.prepareStatement("SELECT * FROM BOOK45 WHERE BCODE=?");
			PreparedStatement ps4=con.prepareStatement("UPDATE BOOK45 SET BPRICE=?, BQTY=BQTY+? WHERE BCODE=?");
			PreparedStatement ps5=con.prepareStatement("DELETE FROM BOOK45 WHERE BCODE=?");
			
			System.out.println("==============Welcome==============");
			while(true)
			{
				count2=0;
				System.out.println(" 1.Insert Book \n 2.Display Book Details \n 3.Display Book Details by your choice \n 4.Update Book Price and Book Quantity \n 5.Delete Book \n 6.Exit");
				System.out.println("=================================================");
				System.out.println("Select your choice: ");
				int ch=sc.nextInt();
				sc.nextLine();

				switch(ch)
				{
					case 1:
						System.out.println("Enter Book code: ");
						String bcode1=sc.nextLine();
						System.out.println("Enter Book Name: ");
						String bname=sc.nextLine();
						System.out.println("Enter Book Author Name: ");
						String bauthor=sc.nextLine();
						System.out.println("Enter Book Price: ");
						String bprice=sc.nextLine();
						System.out.println("Enter Book Quantity: ");
						String bqty=sc.nextLine();
						
						ps1.setString(1, bcode1);
						ps1.setString(2, bname);
						ps1.setString(3, bauthor);
						ps1.setString(4, bprice);
						ps1.setString(5, bqty);
						
						int a=ps1.executeUpdate();
						if(a==1)System.out.println("Book Details Inserted Successfully...");
						System.out.println("=================================================");
						break;
						
					case 2:
							ResultSet rs1=ps2.executeQuery();
							while(rs1.next())
							{ count++;
								System.out.println(rs1.getString(1)+"\t"+rs1.getString(2)+"\t\t"+rs1.getString(3)+"\t"+rs1.getString(4)+"\t"+rs1.getString(5));
							}
							if(count<1)System.out.println("No data found... DataBase is Empty...");
							System.out.println("=================================================");
							break;
					case 3:
							System.out.println("Enter Book code: ");
							String bcode3=sc.nextLine();
							ps3.setString(1,bcode3);
							ResultSet rs2=ps3.executeQuery();
							while(rs2.next())
							{
								count2++;
								System.out.println(rs2.getString(1)+"\t"+rs2.getString(2)+"\t"+rs2.getString(3)+"\t"+rs2.getString(4)+"\t"+rs2.getString(5));
							}
							if(count2<1)System.out.println("Invalid Book Code!!!");
							System.out.println("=================================================");
							break;
					case 4:
							System.out.println("Enter Book code: ");
							String bcode4=sc.nextLine();
							System.out.println("Enter Book Price: ");
							String bprice2=sc.nextLine();
							System.out.println("Enter Book Quantity: ");
							String bqty2=sc.nextLine();
												
							ps4.setString(3, bcode4);
							ps4.setString(1, bprice2);
							ps4.setString(2, bqty2);
							int b=ps4.executeUpdate();
							if(b==1)System.out.println("Book Details Updated Successfully...");
							System.out.println("=================================================");
							break;
					case 5:
							System.out.println("Enter Book code: ");
							String bcode5=sc.nextLine();
							ps5.setString(1, bcode5);
							int c=ps5.executeUpdate();
							if(c==1)System.out.println("Book Deleted Successfully...");
							System.out.println("=================================================");
							break;
					case 6:
						System.out.println("Visit Again...");
						System.exit(0);
						
					default :System.out.println("Invalid Selection!!!");
							System.out.println("=================================================");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		sc.close();
	}

}
