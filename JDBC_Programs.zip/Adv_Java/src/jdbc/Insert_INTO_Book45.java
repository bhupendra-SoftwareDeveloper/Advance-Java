package jdbc;
import java.sql.*;
import java.util.*;
public class Insert_INTO_Book45
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter Book code: ");
			String bcode=sc.nextLine();
			System.out.println("Enter Book Name: ");
			String bname=sc.nextLine();
			System.out.println("Enter Book Author Name: ");
			String bauthor=sc.nextLine();
			System.out.println("Enter Book Price: ");
			String bprice=sc.nextLine();
			System.out.println("Enter Book Quantity: ");
			String bqty=sc.nextLine();
			
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			Statement stmt=con.createStatement();
			int k=stmt.executeUpdate("INSERT INTO BOOK45 VALUES('"+bcode+"','"+bname+"','"+bauthor+"','"+bprice+"','"+bqty+"')");
			
			if(k>0)System.out.println("Book details inserted Successfully...");
			sc.close();
			con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
