package jdbc;
import java.sql.*;
import java.util.*;
public class Transaction_Bank45_MoneyTransfer
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			con.setAutoCommit(false);
			Savepoint sp=con.setSavepoint();
			PreparedStatement ps1=con.prepareCall("SELECT * FROM BANK45 WHERE ACC_NO=?");
			PreparedStatement ps2=con.prepareCall("UPDATE BANK45 SET BALANCE=BALANCE+? WHERE ACC_NO=?");
			
			System.out.println("Enter Home Account Number: ");
			long home_acc=sc.nextLong();
			ps1.setLong(1, home_acc);
			ResultSet rs1=ps1.executeQuery();
			
			if(rs1.next())
			{
				System.out.println("Enter Benificiery Account Number: ");
				long benif_acc=sc.nextLong();
				
				ps1.setLong(1, benif_acc);
				float i=rs1.getFloat(3);
				ResultSet rs2=ps1.executeQuery();
				
				if(rs2.next())
				{
					System.out.println("How much amount you want to transfer: ");
					float amt=sc.nextFloat();
					
					if(amt<=i)
					{
						ps2.setFloat(1,-amt);
						ps2.setLong(2, home_acc);
						int a=ps2.executeUpdate();
						
						ps2.setFloat(1, amt);
						ps2.setLong(2, benif_acc);
						int b=ps2.executeUpdate();
						
						if(a==1 && b==1)
						{
							System.out.println("Transaction Completed Successfully...");
							con.commit();
						}
						else
						{
							System.err.println("Transaction Failed!!!");
							con.rollback(sp);
						}
					}
					else
					{
						System.err.println("Insufficient Balance!!!");
					}
				}
				else
				{
					System.err.println("Invalid Benificiery Account Number!!!");
				}
			}
			else
			{
				System.err.println("Invalid Home Account Number!!!");
			}
			
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
