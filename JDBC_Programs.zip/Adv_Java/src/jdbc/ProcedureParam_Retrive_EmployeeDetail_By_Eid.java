package jdbc;
import java.util.*;
import java.sql.*;
public class ProcedureParam_Retrive_EmployeeDetail_By_Eid
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			CallableStatement cs=con.prepareCall("{call RETRIVEEMPDETAIL45(?,?,?,?,?,?,?,?,?,?,?)}");
			
			System.out.println("Enter Employee Id: ");
			String eid=sc.nextLine();
			
			cs.setString(1, eid);
			cs.registerOutParameter(2,Types.VARCHAR);
			cs.registerOutParameter(3,Types.VARCHAR);
			
			cs.registerOutParameter(4,Types.VARCHAR);
			cs.registerOutParameter(5,Types.VARCHAR);
			cs.registerOutParameter(6,Types.VARCHAR);
			cs.registerOutParameter(7,Types.INTEGER);
			
			cs.registerOutParameter(8,Types.VARCHAR);
			cs.registerOutParameter(9,Types.BIGINT);
			
			cs.registerOutParameter(10,Types.BIGINT);
			cs.registerOutParameter(11,Types.BIGINT);
			
			cs.execute();
			
			System.out.println("Account Holder Name: "+cs.getString(2));
			System.out.println("Designation: "+cs.getString(3));
			System.out.println("House Number: "+cs.getString(4));
			System.out.println("Street Number: "+cs.getString(5));
			System.out.println("City: "+cs.getString(6));
			System.out.println("Pincode: "+cs.getInt(7));
			System.out.println("E-mail: "+cs.getString(8));
			System.out.println("Phone Number: "+cs.getLong(9));
			System.out.println("Basic Salary: "+cs.getFloat(10));
			System.out.println("Total Salary: "+cs.getFloat(11));
			
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
