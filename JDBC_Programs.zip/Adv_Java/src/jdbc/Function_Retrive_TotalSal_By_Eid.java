package jdbc;
import java.util.*;
import java.sql.*;
public class Function_Retrive_TotalSal_By_Eid 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		try
		{
			Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			CallableStatement cs=con.prepareCall("{call ? := RETRIVETOTAL_SALARY(?)}");
			
			System.out.println("Enter Employee ID: ");
			String eid=sc.nextLine();
			
			cs.registerOutParameter(1,Types.FLOAT);
			cs.setString(2, eid);
			cs.execute();
			
			System.out.println("Employee ID: "+eid);
			System.out.println("Total Salary: "+cs.getFloat(1));
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
