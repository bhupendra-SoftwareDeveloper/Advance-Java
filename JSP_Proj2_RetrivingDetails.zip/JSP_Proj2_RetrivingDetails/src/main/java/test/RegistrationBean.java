package test;
import java.io.*;

@SuppressWarnings("serial")
public class RegistrationBean implements Serializable
{
	private String uname,pass,fname,lname,address,email;
	private long phone_no;
	
	public RegistrationBean()
	{
		
	}

	protected String getUname() {
		return uname;
	}

	protected void setUname(String uname) {
		this.uname = uname;
	}

	protected String getPass() {
		return pass;
	}

	protected void setPass(String pass) {
		this.pass = pass;
	}

	protected String getFname() {
		return fname;
	}

	protected void setFname(String fname) {
		this.fname = fname;
	}

	protected String getLname() {
		return lname;
	}

	protected void setLname(String lname) {
		this.lname = lname;
	}

	protected String getAddress() {
		return address;
	}

	protected void setAddress(String address) {
		this.address = address;
	}

	protected String getEmail() {
		return email;
	}

	protected void setEmail(String email) {
		this.email = email;
	}

	protected long getPhone_no() {
		return phone_no;
	}

	protected void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	
	
}
