package allOperationOfBook;
import java.sql.*;
public class Check_Book_Availablity 
{
	public static int check(BookBean bb)
	{
		int k=0;
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM BOOK45 WHERE BCODE=?");
			ps.setString(1, bb.getId());
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) k++;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
