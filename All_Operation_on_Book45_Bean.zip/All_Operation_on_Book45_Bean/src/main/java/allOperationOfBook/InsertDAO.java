package allOperationOfBook;
import java.sql.*;
public class InsertDAO
{
	int k=0;
	public int insert(BookBean bb)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("INSERT INTO BOOK45 VALUES(?,?,?,?,?)");
			ps.setString(1, bb.getId());
			ps.setString(2, bb.getBname());
			ps.setString(3, bb.getAname());
			ps.setFloat(4, bb.getPrice());
			ps.setInt(5, bb.getQty());
			
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
