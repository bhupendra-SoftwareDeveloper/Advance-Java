package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/Book_Author_Name_Update")
public class Update_Book_AuthorName extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		
		BookBean bb=new BookBean();
		bb.setId(req.getParameter("bcode"));
		bb.setAname(req.getParameter("newBookAuthorName"));
		
		int k=Update_Book_AuthorName_DAO.update(bb);
		PrintWriter pw=res.getWriter();
		
		if(k!=0)
		{
			pw.println("<br>");
			pw.println("Book Author Name Updated Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("<br>");
			pw.println("Book Author Name Not Updated!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
