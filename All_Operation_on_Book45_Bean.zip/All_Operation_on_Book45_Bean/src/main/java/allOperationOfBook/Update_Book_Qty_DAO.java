package allOperationOfBook;
import java.sql.*;

public class Update_Book_Qty_DAO
{
	public static int update(BookBean bb)
	{
		int k=0;
		
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE BOOK45 SET BQTY=? WHERE BCODE=?");
			ps.setInt(1, bb.getQty());
			ps.setString(2, bb.getId());
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
