package allOperationOfBook;

import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/updatableField")
public class Select_UpdatableField_Book_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws ServletException,IOException
	{
		
		String field=req.getParameter("updt");
		
		if(field.equals("Book Name"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("Updating_BookName.html");
			rd.forward(req, res);
		}
		else if(field.equals("Book Author Name"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("Updating_Book_AuthorName.html");
			rd.forward(req, res);
		}
		else if(field.equals("Book Price"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("Updating_Book_Price.html");
			rd.forward(req, res);
		}
		else if(field.equals("Book Quantity"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("Updating_Book_Quantity.html");
			rd.forward(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
