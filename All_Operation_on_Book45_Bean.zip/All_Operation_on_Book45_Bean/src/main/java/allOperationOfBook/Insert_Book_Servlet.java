package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/add")
public class Insert_Book_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		BookBean bb=new BookBean();
		
		bb.setId(req.getParameter("id"));
		bb.setBname(req.getParameter("bname"));
		bb.setAname(req.getParameter("aname"));
		bb.setPrice(Float.parseFloat(req.getParameter("price")));
		bb.setQty(Integer.parseInt(req.getParameter("qty")));
		
		int k=new InsertDAO().insert(bb);
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
	
		if(k>0)
		{
			pw.println("<br>");
			pw.println("Data inserted Successfully...");
			
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
		else pw.println("<br>Data Not Added...");
	}
	
	public void destroy()
	{
		//No Code
	}
}
