package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/delete")
public class Delete_Book_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws ServletException,IOException
	{
		BookBean bb=new BookBean();
		bb.setId(req.getParameter("id"));
		
		int k=DeleteDAO.delete(bb);
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		if(k!=0)
		{
			pw.println("Book Deleted Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("Book NOT Deleted!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
