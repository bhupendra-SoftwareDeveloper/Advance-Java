package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/update")
public class Update_Book_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res)throws ServletException,IOException
	{
		BookBean bb=new BookBean();
		bb.setId(req.getParameter("id2"));
		
		int check=Check_Book_Availablity.check(bb);
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		if(check==0)
		{
			pw.println("Invalid Book Code!!!");
			RequestDispatcher rd=req.getRequestDispatcher("EditBook.html");
			rd.include(req, res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("EditBook2.html");
			rd.include(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
