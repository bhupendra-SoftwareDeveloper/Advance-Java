package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/Book_Qty_Update")
public class Update_Book_Qty extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		
		BookBean bb=new BookBean();
		bb.setId(req.getParameter("bcode"));
		bb.setQty(Integer.parseInt(req.getParameter("newBookQty")));
		
		int k=Update_Book_Qty_DAO.update(bb);
		PrintWriter pw=res.getWriter();
		
		if(k!=0)
		{
			pw.println("<br>");
			pw.println("Book Quantity Updated Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("<br>");
			pw.println("Book Quantity Not Updated!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
