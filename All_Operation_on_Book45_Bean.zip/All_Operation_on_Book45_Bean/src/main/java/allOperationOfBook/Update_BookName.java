package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/Book_Name_Update")
public class Update_BookName extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		
		BookBean bb1=new BookBean();
		bb1.setId(req.getParameter("bcode"));
		bb1.setBname(req.getParameter("newBookName"));
		int k=Update_Book_Name_DAO.update(bb1);
		PrintWriter pw=res.getWriter();
		
		if(k!=0)
		{
			pw.println("<br>");
			pw.println("Book Name Updated Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("<br>");
			pw.println("Book Name Not Updated!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
