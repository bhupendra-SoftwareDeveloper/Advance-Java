package allOperationOfBook;
import java.sql.*;

public class Update_Book_Price_DAO
{
	public static int update(BookBean bb)
	{
		int k=0;
		
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE BOOK45 SET BPRICE=? WHERE BCODE=?");
			ps.setFloat(1, bb.getPrice());
			ps.setString(2, bb.getId());
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
