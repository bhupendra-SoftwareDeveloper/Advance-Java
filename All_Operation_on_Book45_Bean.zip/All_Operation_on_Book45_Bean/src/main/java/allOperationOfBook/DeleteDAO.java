package allOperationOfBook;
import java.sql.*;
public class DeleteDAO
{
	
	public static int delete(BookBean bb)
	{
		int k=0;
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("DELETE FROM BOOK45 WHERE BCODE=?");
			ps.setString(1, bb.getId());
			
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
