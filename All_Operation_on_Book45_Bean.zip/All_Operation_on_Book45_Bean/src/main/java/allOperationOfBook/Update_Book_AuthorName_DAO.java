package allOperationOfBook;
import java.sql.*;

public class Update_Book_AuthorName_DAO
{
	public static int update(BookBean bb)
	{
		int k=0;
		
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE BOOK45 SET BAUTHOR=? WHERE BCODE=?");
			ps.setString(1, bb.getAname());
			ps.setString(2, bb.getId());
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
