package allOperationOfBook;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.util.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/ViewBook")

public class ViewBook extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws ServletException,IOException
	{
		ArrayList<BookBean> al=new ViewDAO().retrive();
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		if(al.size()==0)
			pw.println("<br>Data Not Retrived...");
		else
		{
			Iterator<BookBean> it=al.iterator();
			while(it.hasNext())
			{
				BookBean bb=(BookBean)it.next();
				pw.println(bb.getId()+"&nbsp;&nbsp;"+bb.getBname()
				+"&nbsp;&nbsp;"+bb.getAname()+"&nbsp;&nbsp;"
				+bb.getPrice()+"&nbsp;&nbsp;"+bb.getQty());
				pw.println("<br>");
			}
			
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
