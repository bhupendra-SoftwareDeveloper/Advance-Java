package sendRedirectMethodProg;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/first")
public class FirstServlet extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String name=req.getParameter("uname");
		String email=req.getParameter("email");
		
		res.sendRedirect("http://localhost:8085/TestApp2_sendRedirect_Method/second?uname="+name+"&email="+email);
	}
	
}
