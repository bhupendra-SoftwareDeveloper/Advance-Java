package retrivingProductDetails;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/first")
public class First_Retrive_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		ProductBean pb=new ViewDAO().retrive(req);
		
		if(pb==null)
		{
			pw.println("Invalid Product Code!!!");
			RequestDispatcher rd=req.getRequestDispatcher("ViewProduct.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("<form action='second' method='post'>");
			pw.println("<input type='hidden' value="+pb.getId()+" name='code'>");
			pw.println("<input type='hidden' value="+pb.getName()+" name='name'>");
			pw.println("<input type='hidden' value="+pb.getPrice()+" name='price'>");
			pw.println("<input type='hidden' value="+pb.getQty()+" name='qty'>");
			pw.println("<input type='submit' value='Retrive ProductDetails'></form>");
		}
	}
}
