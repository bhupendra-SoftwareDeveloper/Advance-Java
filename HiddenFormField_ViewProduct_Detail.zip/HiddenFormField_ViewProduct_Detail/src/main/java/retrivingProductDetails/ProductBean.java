package retrivingProductDetails;
import java.io.Serializable;

@SuppressWarnings("serial")
public class ProductBean implements Serializable
{
	private String id,name;
	private float price;
	private int qty;
	
	public ProductBean()
	{
		super();
	}

	protected String getId() {
		return id;
	}

	protected void setId(String id) {
		this.id = id;
	}

	protected String getName() {
		return name;
	}

	protected void setName(String name) {
		this.name = name;
	}

	protected float getPrice() {
		return price;
	}

	protected void setPrice(float price) {
		this.price = price;
	}

	protected int getQty() {
		return qty;
	}

	protected void setQty(int qty) {
		this.qty = qty;
	}
	
	
}
