package retrivingProductDetails;
import  java.sql.*;
import javax.servlet.http.*;

public class ViewDAO
{
	ProductBean pb;
	public ProductBean retrive(HttpServletRequest req)
	{
		try
		{	
			Connection con=DBConnection.getCon();
			
			PreparedStatement ps=con.prepareStatement("SELECT * FROM PRODUCT45 WHERE PCODE=?");
			ps.setString(1, req.getParameter("pcode"));
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				pb=new ProductBean();
				pb.setId(rs.getString(1));
				pb.setName(rs.getString(2));
				pb.setPrice(rs.getFloat(3));
				pb.setQty(rs.getInt(4));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return pb;
	}
}
