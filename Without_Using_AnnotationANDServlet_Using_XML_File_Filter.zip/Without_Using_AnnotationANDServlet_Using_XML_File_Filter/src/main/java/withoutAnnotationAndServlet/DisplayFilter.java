package withoutAnnotationAndServlet;
import javax.servlet.*;
import java.io.*;

public class DisplayFilter implements Filter
{
	FilterConfig fc;
	public void init(FilterConfig fc)
	{
		this.fc=fc;
	}
	
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("Welcome "+req.getParameter("uname"));
		pw.println("<br>====Filter Detail====");
		pw.println("<br>Filter Name: "+fc.getFilterName());
		pw.println("<br>Config Value: "+fc.getInitParameter("a"));
	}
}
