package test;

public class Arunesh_sir_HashTag {

	public static void main(String[] args)
	{
		int hastag=0,hash=1,count=0,alp=0;
		String s="who watches tom and jerry #mychildhood# # #myboyhood#";
		
		String sar[]=s.split(" ");
		
		for(int i=0;i<sar.length;i++)
		{	hastag=0;hash=1;alp=0;
			for(int j=0;j<sar[i].length();j++)
			{	
				if((sar[i]).charAt(0)=='#')
				{
					hastag++;
					if(hastag>1)
					{
						if((((sar[i]).charAt(j))>='A' && ((sar[i]).charAt(j))<='Z')||(((sar[i]).charAt(j))>='a' && ((sar[i]).charAt(j))<='z')||(((sar[i]).charAt(j))=='#'))
						{
							if(((sar[i]).charAt(j))=='#')hash++;
							else alp++;
						}
					}
					
				}
				if(hash==2&&alp>0)count++;
			}
		}
		System.out.println(count);
	}

}
