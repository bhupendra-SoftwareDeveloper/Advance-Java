package test;
import java.sql.*;
import javax.servlet.http.*;

public class LoginDAO
{
	private String s;
	
	public String checkLogin(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM USERREG45 WHERE UNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("uname"));
			ps.setString(2, req.getParameter("pass"));
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				s=rs.getString(3);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return s;
	}
}
