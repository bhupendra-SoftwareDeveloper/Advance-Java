package user;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/editPass")
public class Change_Password_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		int k=new ChangePass_DAO().change(req);
		
		if(k!=0)
		{
			pw.println("Password Changed Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("Invalid Input Details!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Change_Pass.html");
			rd.include(req, res);
		}
	}
}
