package user;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/editPhone")
public class Change_Phone_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		int k=new ChangePhone_DAO().change(req);
		
		if(k!=0)
		{
			pw.println("Phone Number Changed Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("Link.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("Invalid Input Details!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Change_Phone.html");
			rd.include(req, res);
		}
	}
}
