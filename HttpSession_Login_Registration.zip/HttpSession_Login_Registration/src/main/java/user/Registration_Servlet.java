package user;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/registration")
public class Registration_Servlet extends HttpServlet
{
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException
	{
		RegistrationBean rg=new RegistrationBean();
		rg.setUname(req.getParameter("uname"));
		rg.setPass(req.getParameter("pass"));
		rg.setFname(req.getParameter("fname"));
		rg.setLname(req.getParameter("lname"));
		rg.setAddress(req.getParameter("address"));
		rg.setEmail(req.getParameter("email"));
		rg.setPhone_no(Long.parseLong(req.getParameter("phone")));
		
		int k=Registration_DAO.register(rg);
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		if(k!=0)
		{
			pw.println("<br>");
			pw.println("Registration Successfull...");
		}
		else
		{
			pw.println("<br>");
			pw.println("Something Wrong In Registration Process!!!");
		}
		RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
		rd.include(req, res);
	}
	
}
