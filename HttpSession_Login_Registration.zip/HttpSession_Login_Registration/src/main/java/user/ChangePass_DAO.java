package user;
import java.sql.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
public class ChangePass_DAO extends HttpServlet
{
	int k;
	int change(HttpServletRequest req)
	{
		String s,s2;
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE USERREG45 SET PWORD=? WHERE UNAME=? AND PHONE_NO=?");
			ps.setString(1, req.getParameter("newpass"));
			ps.setString(2, req.getParameter("uname"));
			ps.setString(3, req.getParameter("phone"));
			k=ps.executeUpdate();
			
			s=req.getParameter("newpass");
			s2=req.getParameter("newpass2");
			if(s.equals(s2));
			else k=0;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
	}
}
