package sendRedirectMethodProg;
import java.io.*;
import javax.servlet.annotation.*;
import javax.servlet.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
@WebServlet("/second")
public class SecondServlet extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("----Details----");
		pw.println("<br>UserName: "+req.getParameter("uname"));
		pw.println("<br>Email: "+req.getParameter("email"));
	}
}
