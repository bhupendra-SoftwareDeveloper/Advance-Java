package test;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/dis")
public class FirstServlet extends GenericServlet
{
	public void service(ServletRequest req, ServletResponse res) throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println(req.getParameter("bcode"));
		pw.println(req.getParameter("bname"));
		pw.println(req.getParameter("bauth"));
		pw.println(req.getParameter("bprice"));
		pw.println(req.getParameter("bqty"));
	}
}
