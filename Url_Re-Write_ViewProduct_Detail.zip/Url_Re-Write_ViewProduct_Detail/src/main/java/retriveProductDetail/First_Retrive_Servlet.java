package retriveProductDetail;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
@WebServlet("/view")
public class First_Retrive_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		ProductBean pb=new ViewDAO().retrive(req);
		if(pb==null)
		{
			pw.println("Invalid Product Code!!!<br>");
			RequestDispatcher rd=req.getRequestDispatcher("ViewProduct.html");
			rd.include(req,res);
		}
		else
		{
			pw.println("<a href='second?code="+pb.getId()
			+"&name="+pb.getName()
			+"&price="+pb.getPrice()
			+"&qty="+pb.getQty()+"'>ViewProduct</a>");
		}
	}
}
