package requestDispatcher;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/choice")
public class Choice_Book_and_product_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res)throws IOException,ServletException
	{
		String b=req.getParameter("button");
		
		if(b.equals("Book"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("Book.html");
			rd.forward(req, res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("Product.html");
			rd.forward(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
