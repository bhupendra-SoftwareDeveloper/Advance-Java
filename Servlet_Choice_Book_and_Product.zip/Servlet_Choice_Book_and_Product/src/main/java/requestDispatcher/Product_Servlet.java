package requestDispatcher;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/display_product")
public class Product_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.println("<h2>====Product Details====</h2>");
		pw.println("Product Id: "+req.getParameter("id"));
		pw.println("<br>Product Name: "+req.getParameter("name"));
		pw.println("<br>Book Price: "+Float.parseFloat(req.getParameter("price")));
		pw.println("<br>Book Quantity: "+Integer.parseInt(req.getParameter("qty")));
		pw.println("<h1> </h1>");
		RequestDispatcher rd=req.getRequestDispatcher("Home.html");
		rd.include(req, res);	//To redirect to "Book_and_product.html" page again
	}
	
	public void destroy()
	{
		//No Code
	}
}
