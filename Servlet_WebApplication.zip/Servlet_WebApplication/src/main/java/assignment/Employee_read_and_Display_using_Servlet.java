package assignment;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/employee45")
public class Employee_read_and_Display_using_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException
	{
		String id=req.getParameter("id");
		String name=req.getParameter("name");
		String desg=req.getParameter("desg");
		float bs=Float.parseFloat(req.getParameter("bs"));
		float hra=bs*93/100;
		float da=bs*63/100;
		float totalsal=bs+hra+da;
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("----Employee Details----");
		pw.println("<br>Employee Id: "+id);
		pw.println("<br>Employee Name: "+name);
		pw.println("<br>Designation: "+desg);
		pw.println("<br>Basic Salary: "+bs);
		pw.println("<br>Total Salary: "+totalsal);
	}
	
	public void destroy()
	{
		
	}
}
