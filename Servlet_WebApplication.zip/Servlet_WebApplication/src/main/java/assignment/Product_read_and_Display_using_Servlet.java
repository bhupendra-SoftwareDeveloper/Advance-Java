package assignment;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/product45")
public class Product_read_and_Display_using_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req,ServletResponse res) throws IOException 
	{
		String pid=req.getParameter("id");
		String name=req.getParameter("name");
		float price=Float.parseFloat(req.getParameter("price"));
		int qty=Integer.parseInt(req.getParameter("qty"));
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("====Product Details====");
		pw.println("<br>Product Id: "+pid);
		pw.println("<br>Product Name: "+name);
		pw.println("<br>Product Price: "+price);
		pw.println("<br>Product Quantity: "+qty);
	}
	
	public void destroy()
	{
		//No Code
	}
}
