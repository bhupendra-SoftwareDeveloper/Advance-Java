package demo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/sample")
public class FirstProgram_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException
	{
		String uName=req.getParameter("user");
		String pass=req.getParameter("pass");
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("====Details====");
		pw.println("<br>Username: "+uName);
		pw.println("<br>Password: "+pass);
	}
	
	public void destroy()
	{
		//No Code
	}
}
