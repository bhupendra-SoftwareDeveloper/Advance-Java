package requestDispatcher;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/choice")
public class Choice_Add_Sub_Multi_Div_Modulo_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res)throws IOException, ServletException
	{
		String button=req.getParameter("sb1");
		
		if(button.equals("Addition"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("add");
			rd.forward(req,res);
		}
		else if(button.equals("Subtraction"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("sub");
			rd.forward(req, res);
		}
		else if(button.equals("Division"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("div");
			rd.forward(req, res);
		}
		else if(button.equals("Multiplication"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("multi");
			rd.forward(req, res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("modulo");
			rd.forward(req, res);
		}
	}
	
	public void destroy()
	{
		//No Code
	}
}
