package requestDispatcher;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/div")
public class Choice_Division_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res)throws IOException
	{
		int a=Integer.parseInt(req.getParameter("fv"));
		int b=Integer.parseInt(req.getParameter("sv"));
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.println("Division of "+a+" and "+b+" is = "+(a/b));
	}
	
	public void destroy()
	{
		//No Code
	}
}
