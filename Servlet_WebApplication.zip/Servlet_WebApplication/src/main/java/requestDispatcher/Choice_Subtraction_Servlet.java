package requestDispatcher;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/sub")
public class Choice_Subtraction_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		int a=Integer.parseInt(req.getParameter("fv"));
		int b=Integer.parseInt(req.getParameter("sv"));
		
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		pw.println("Subtraction of "+a+" and "+b+" is = "+(a-b));
	}
	
	public void destroy()
	{
		//No Code
	}
}
