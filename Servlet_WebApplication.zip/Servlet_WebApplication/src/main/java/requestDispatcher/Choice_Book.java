package requestDispatcher;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/book")
public class Choice_Book extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{
		String id=req.getParameter("id");
		String bname=req.getParameter("bname");
		String aname=req.getParameter("aname");
		float price=Float.parseFloat(req.getParameter("price"));
		int qty=Integer.parseInt(req.getParameter("qty"));
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		pw.println("====Book Details====");
		pw.println("<br>Book ID: "+id);
		pw.println("<br>Book Name: "+bname);
		pw.println("<br>Author Name: "+aname);
		pw.println("<br>Price: "+price);
		pw.println("<br>Quantity: "+qty);
	}
	
	public void destroy()
	{
		//No Code
	}
}
