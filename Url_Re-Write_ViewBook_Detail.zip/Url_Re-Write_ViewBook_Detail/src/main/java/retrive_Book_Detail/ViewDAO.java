package retrive_Book_Detail;
import java.sql.*;
import javax.servlet.http.*;

public class ViewDAO
{
	BookBean bb;
	public BookBean retrive(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM BOOK45 WHERE BCODE=?");
			ps.setString(1, req.getParameter("bcode"));
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				bb=new BookBean();
				bb.setId(rs.getString(1));
				bb.setBname(rs.getNString(2));
				bb.setAname(rs.getString(3));
				bb.setPrice(rs.getFloat(4));
				bb.setQty(rs.getInt(5));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return bb;
	}
}
