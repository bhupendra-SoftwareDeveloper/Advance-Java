package retrive_Book_Detail;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/view")
public class First_Retrive_BookDetail extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		BookBean bb=new ViewDAO().retrive(req);
		
		if(bb==null)
		{
			pw.println("Invalid Book Code!!!");
			RequestDispatcher rd=req.getRequestDispatcher("ViewBook.html");
			rd.include(req,res);
		}
		else
		{
			pw.println("<a href='second?code="+bb.getId()
			+"&bname="+bb.getBname()
			+"&aname="+bb.getAname()
			+"&price="+bb.getPrice()
			+"&qty="+bb.getQty()+"'>View BookDetail</a>");
		}
	}
}
