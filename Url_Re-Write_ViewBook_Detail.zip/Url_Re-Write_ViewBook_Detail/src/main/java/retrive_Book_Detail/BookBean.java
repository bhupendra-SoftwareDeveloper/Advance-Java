package retrive_Book_Detail;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BookBean implements Serializable
{
	private String id,bname,aname;
	private float price;
	private int qty;
	
	public BookBean()
	{
		
	}

	protected String getId() {
		return id;
	}

	protected void setId(String id) {
		this.id = id;
	}

	protected String getBname() {
		return bname;
	}

	protected void setBname(String bname) {
		this.bname = bname;
	}

	protected String getAname() {
		return aname;
	}

	protected void setAname(String aname) {
		this.aname = aname;
	}

	protected float getPrice() {
		return price;
	}

	protected void setPrice(float price) {
		this.price = price;
	}

	protected int getQty() {
		return qty;
	}

	protected void setQty(int qty) {
		this.qty = qty;
	}
	
	
}
