package retrive_Book_Detail;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/second")
public class Second_Retrive_BookDetail extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("<br>====Book Details====<br>");
		pw.println("Book Code: "+req.getParameter("code"));
		pw.println("<br>Book Name: "+req.getParameter("bname"));
		pw.println("<br>Book Author Name: "+req.getParameter("aname"));
		pw.println("<br>Book Price: "+req.getParameter("price"));
		pw.println("<br>Book Quantity: "+req.getParameter("qty"));
		pw.println("<br><br><a href='ViewBook.html'>Home</a>");
	}
}
