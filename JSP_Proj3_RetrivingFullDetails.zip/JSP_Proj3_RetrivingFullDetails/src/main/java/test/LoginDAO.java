package test;
import java.sql.*;
import javax.servlet.http.*;

public class LoginDAO
{
	private ResultSet rs;
	public ResultSet checkLogin(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM USERREG45 WHERE UNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("uname"));
			ps.setString(2, req.getParameter("pass"));
			
			rs=ps.executeQuery();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}
}
