package retriveBookDetail;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/first")
public class First_Retrive_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		BookBean bb=new ViewDAO().retrive(req);
		
		if(bb==null)
		{
			pw.println("Invalid Book Code!!!");
			RequestDispatcher rd=req.getRequestDispatcher("ViewBook.html");
			rd.include(req,res);
		}
		else
		{
			pw.println("<form action='second' method='post'>");
			pw.println("<input type='hidden' value='"+bb.getId()+"' name='bcode'>");
			pw.println("<input type='hidden' value='"+bb.getBname()+"' name='bname'>");
			pw.println("<input type='hidden' value='"+bb.getAname()+"' name='aname'>");
			pw.println("<input type='hidden' value='"+bb.getPrice()+"' name='price'>");
			pw.println("<input type='hidden' value='"+bb.getQty()+"' name='qty'>");
			pw.println("<input type='submit' value='Retrive BookDetail'>");
			pw.println("</form>");
		}
	}
}
