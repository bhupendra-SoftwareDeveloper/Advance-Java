package retriveBookDetail;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/second")
public class Second_Retrive_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		pw.println("<br>====Book Details====<br>");
		pw.println("Book Code: "+req.getParameter("bcode"));
		pw.println("<br>Book Name: "+req.getParameter("bname"));
		pw.println("<br>Book Author Name: "+req.getParameter("aname"));
		pw.println("<br>Book Price: "+req.getParameter("price"));
		pw.println("<br>Book Quantity: "+req.getParameter("qty"));
		pw.println("<br><br><a href='ViewBook.html'>Home</a>");
	}
}
