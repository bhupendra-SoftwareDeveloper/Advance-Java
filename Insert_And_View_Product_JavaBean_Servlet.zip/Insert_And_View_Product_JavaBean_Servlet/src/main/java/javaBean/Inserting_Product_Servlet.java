package javaBean;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;

@SuppressWarnings("serial")
@WebServlet("/insertProduct")
public class Inserting_Product_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws ServletException,IOException
	{
		ProductBean pb=new ProductBean();
		res.setContentType("text/html");
		
		pb.setId(req.getParameter("id"));
		pb.setName(req.getParameter("name"));
		pb.setPrice(Float.parseFloat(req.getParameter("price")));
		pb.setQty(Integer.parseInt(req.getParameter("qty")));
		
		int k=InsertDAO.insert(pb);
		PrintWriter pw=res.getWriter();
		
		if(k>0)
		{
			pw.println("<br>");
			pw.println("Data Inserted Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("Choice.html");
			rd.include(req, res);
			pw.println("<br>");
		}	
		else pw.println("<br>Data Not Inserted...");
		
	}
	
	public void destroy()
	{
		//No Code
	}
}
