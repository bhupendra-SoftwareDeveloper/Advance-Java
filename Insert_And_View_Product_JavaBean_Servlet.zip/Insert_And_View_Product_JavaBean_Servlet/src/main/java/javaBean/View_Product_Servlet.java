package javaBean;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.util.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/view")
public class View_Product_Servlet extends GenericServlet
{
	public void init()
	{
		//No Code
	}
	
	public void service(ServletRequest req, ServletResponse res) throws IOException,ServletException
	{ 
		ArrayList<ProductBean> al=ViewDAO.retrive();
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		if(al.size()!=0)
		{
			Iterator<ProductBean>it=al.iterator();
			while(it.hasNext())
			{
				ProductBean pb=(ProductBean)it.next();
				pw.println("<br>");
				pw.println(pb.getId()+"&nbsp;&nbsp;"+pb.getName()+"&nbsp;&nbsp;"+pb.getPrice()+"&nbsp;&nbsp;"+pb.getQty());
				pw.println("<br>");
				RequestDispatcher rd=req.getRequestDispatcher("Link.html");
				rd.include(req,res);
			}
		}
		else pw.println("<br>Not Updated...");
		
		RequestDispatcher rd=req.getRequestDispatcher("Login.html");
		rd.include(req, res);
	}
	
	public void destroy()
	{
		//No Code
	}
}
