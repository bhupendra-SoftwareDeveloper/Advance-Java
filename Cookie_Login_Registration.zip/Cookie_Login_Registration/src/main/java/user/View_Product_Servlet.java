package user;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.util.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/view")
public class View_Product_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException
	{ 
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		Cookie c[]=req.getCookies();
		if(c==null)
		{
			pw.println("Session Expired...");
			RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
			rd.include(req, res);
		}
		else
		{
			String fName=c[0].getValue();
			pw.println("Page of "+fName+"<br>");
			pw.println("<br>");

			ArrayList<ProductBean> al=ViewDAO.retrive();
		
			if(al.size()!=0)
			{
				Iterator<ProductBean>it=al.iterator();
				while(it.hasNext())
				{
					ProductBean pb=(ProductBean)it.next();
					pw.println("<br>");
					pw.println(pb.getId()+"&nbsp;&nbsp;"+pb.getName()+"&nbsp;&nbsp;"+pb.getPrice()+"&nbsp;&nbsp;"+pb.getQty());
					pw.println("<br>");
				}
			}
			else pw.println("<br>Not Updated...");
			
			pw.println("<br>");
			RequestDispatcher rd=req.getRequestDispatcher("Link.html");
			rd.include(req, res);
		}
	}
		
}


