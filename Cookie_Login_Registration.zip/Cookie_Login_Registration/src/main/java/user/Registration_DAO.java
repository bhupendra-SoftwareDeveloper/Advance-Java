package user;
import java.sql.*;

public class Registration_DAO
{
	public static int register(RegistrationBean rg)
	{
		int k=0;
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("INSERT INTO USERREG45 VALUES(?,?,?,?,?,?,?)");
			ps.setString(1, rg.getUname());
			ps.setString(2, rg.getPass());
			ps.setString(3, rg.getFname());
			ps.setString(4, rg.getLname());
			ps.setString(5, rg.getEmail());
			ps.setString(6, rg.getAddress());
			ps.setLong(7, rg.getPhone_no());
			
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return k;
	}
}
