package user;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import javax.servlet.*;

@SuppressWarnings("serial")
@WebServlet("/LogOut")
public class Logout_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		Cookie c[]=req.getCookies();
		
		if(c==null)
			pw.println("Session Expired...");
		else
		{
			String s=c[0].getValue();
			c[0].setMaxAge(0);
			pw.println(s+" User Logout Successfully....<br>");
			
		}
		
		RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
		rd.include(req, res);

	}
}
