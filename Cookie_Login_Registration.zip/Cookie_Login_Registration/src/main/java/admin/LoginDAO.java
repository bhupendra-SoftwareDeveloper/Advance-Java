package admin;
import java.sql.*;
import javax.servlet.http.*;

public class LoginDAO
{
	private AdminBean ab;
	public AdminBean check(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM ADMIN45 WHERE ADMINNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("adminName"));
			ps.setString(2, req.getParameter("adminPass"));
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				ab=new AdminBean();
				ab.setAdminName(rs.getString(1));
				ab.setPass(rs.getString(2));
				ab.setfName(rs.getString(3));
				ab.setlName(rs.getString(4));
				ab.setEmail(rs.getString(5));
				ab.setPhone_no(rs.getString(6));
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ab;
	}
}
