package admin;
import java.sql.*;
import javax.servlet.http.*;

public class DeleteDAO
{
	
	static int check(HttpServletRequest req)
	{
		int k=0;
		try
		{
			Connection con=DBConnection.getCon();
			
				PreparedStatement ps=con.prepareStatement("DELETE FROM PRODUCT45 WHERE PCODE=?");
				ps.setString(1, req.getParameter("pcode"));
				k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
	}
}
