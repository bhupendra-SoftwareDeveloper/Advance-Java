package admin;
import java.io.*;

@SuppressWarnings("serial")
public class AdminBean implements Serializable
{
	private String adminName,pass,fName,lName,email,phone_no;
	
	public AdminBean()
	{
		
	}

	protected String getAdminName() {
		return adminName;
	}

	protected void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	protected String getPass() {
		return pass;
	}

	protected void setPass(String pass) {
		this.pass = pass;
	}

	protected String getfName() {
		return fName;
	}

	protected void setfName(String fName) {
		this.fName = fName;
	}

	protected String getlName() {
		return lName;
	}

	protected void setlName(String lName) {
		this.lName = lName;
	}

	protected String getEmail() {
		return email;
	}

	protected void setEmail(String email) {
		this.email = email;
	}

	protected String getPhone_no() {
		return phone_no;
	}

	protected void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	
	
}
