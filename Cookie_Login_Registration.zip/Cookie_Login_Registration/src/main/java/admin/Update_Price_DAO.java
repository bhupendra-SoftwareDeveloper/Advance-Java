package admin;
import java.sql.*;
import javax.servlet.http.*;

public class Update_Price_DAO
{
	int k=0;
	int update(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE PRODUCT45 SET PPRICE=? WHERE PCODE=?");
			ps.setString(1, req.getParameter("editprice"));
			ps.setString(2, req.getParameter("editcode"));
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
	}
}
