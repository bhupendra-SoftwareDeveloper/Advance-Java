package admin;
import java.sql.*;
import javax.servlet.http.*;

public class Update_Qty_DAO
{
	int k=0;
	int update(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE PRODUCT45 SET PQTY=? WHERE PCODE=?");
			ps.setString(1, req.getParameter("editqty"));
			ps.setString(2, req.getParameter("editcode"));
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
	}
}
