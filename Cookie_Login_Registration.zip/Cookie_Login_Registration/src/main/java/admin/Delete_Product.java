package admin;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import javax.servlet.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/AdminDelete")
public class Delete_Product extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		Cookie c[]=req.getCookies();
		String name=c[0].getValue();
		pw.println(name+" is performing delete operation<br>");
		
		int k=DeleteDAO.check(req);
		if(k!=0)
		{
			pw.println("Product deleted Successfully...");	
		}
		else
		{
			pw.println("Product not available!!!");
		}
		RequestDispatcher rd=req.getRequestDispatcher("AdminLink.html");
		rd.include(req, res);
	}
}
