package admin;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/AdminLogin")
public class Login_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		AdminBean ab=new LoginDAO().check(req);
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");

		if(ab==null)
		{
			pw.println("Invalid AdminName or Password!!!");
			RequestDispatcher rd=req.getRequestDispatcher("AdminLogin.html");
			rd.include(req, res);
		}
		else
		{
			Cookie ck=new Cookie("fName",ab.getfName());
			res.addCookie(ck);
			pw.println("Welcome "+ab.getfName()+"&nbsp;"+ab.getlName()+"<br>");
			RequestDispatcher rd=req.getRequestDispatcher("AdminLink.html");
			rd.include(req, res);
		}
	}
}
