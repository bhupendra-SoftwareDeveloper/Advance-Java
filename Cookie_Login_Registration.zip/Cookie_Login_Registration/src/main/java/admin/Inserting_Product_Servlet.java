package admin;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*
;
@SuppressWarnings("serial")
@WebServlet("/AdminAdd")
public class Inserting_Product_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		ProductBean pb=new ProductBean();
		res.setContentType("text/html");
		
		pb.setId(req.getParameter("id"));
		pb.setName(req.getParameter("name"));
		pb.setPrice(Float.parseFloat(req.getParameter("price")));
		pb.setQty(Integer.parseInt(req.getParameter("qty")));
		
		int k=InsertDAO.insert(pb);
		PrintWriter pw=res.getWriter();
		
		if(k>0)
		{
			pw.println("<br>");
			pw.println("Data Inserted Successfully...<br>");
			pw.println("<br>");
		}	
		else pw.println("<br>Data Not Inserted...");
		
		RequestDispatcher rd=req.getRequestDispatcher("AdminLink.html");
		rd.include(req, res);
	}
}
