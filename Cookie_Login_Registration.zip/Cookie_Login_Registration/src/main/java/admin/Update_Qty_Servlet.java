package admin;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
@WebServlet("/editQty")
public class Update_Qty_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		int k=new Update_Qty_DAO().update(req);
		
		if(k==0)
		{
			pw.println("Invalid Product Code!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Update_Qty.html");
			rd.include(req, res);
		}
		else
		{
			pw.println("Product Quantity Updated Successfully...");
			RequestDispatcher rd=req.getRequestDispatcher("AdminLink.html");
			rd.include(req, res);
		}
	}
}
