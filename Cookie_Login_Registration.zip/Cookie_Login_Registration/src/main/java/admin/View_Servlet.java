package admin;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/AdminView")
public class View_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		Cookie c[]=req.getCookies();
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		if(c==null)
		{
			pw.println("Session Expired...");
			RequestDispatcher rd=req.getRequestDispatcher("AdminLogin.html");
			rd.include(req, res);
		}
		else
		{
			
			String name=c[0].getValue();
			pw.println("Page of "+name+"<br>");
			ArrayList<ProductBean> al=ViewDAO.retrive();
			
			if(al.size()==0)
				pw.println("No Data Available...");
			
			else
			{
				Iterator<ProductBean> it=al.iterator();
				while(it.hasNext())
				{
					ProductBean pb=(ProductBean)it.next();
					pw.println("<br>");
					pw.println(pb.getId()+"&nbsp;&nbsp;"+pb.getName()+"&nbsp;&nbsp;"+pb.getPrice()+"&nbsp;&nbsp;"+pb.getQty());
					pw.println("<br>");
				}
			}
			
			RequestDispatcher rd=req.getRequestDispatcher("AdminLink.html");
			rd.include(req, res);
		}
			
	}
}
