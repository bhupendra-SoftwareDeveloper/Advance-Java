package admin;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import javax.servlet.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/AdminLogOut")
public class LogOut_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		Cookie c[]=req.getCookies();
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		if(c==null)
			pw.println("Session Expired...");
		else
		{
			c[0].setMaxAge(0);
			pw.println("Admin LoggedOut Successfully...");
		}
		RequestDispatcher rd=req.getRequestDispatcher("AdminLogin.html");
		rd.include(req, res);
	}
}
