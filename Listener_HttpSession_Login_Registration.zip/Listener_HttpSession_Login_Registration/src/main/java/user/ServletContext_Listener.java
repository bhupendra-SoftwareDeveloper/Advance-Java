package user;
import javax.servlet.*;
import javax.servlet.annotation.*;

@WebListener
public class ServletContext_Listener implements ServletContextListener
{
	public void contextInitialized(ServletContextEvent sce)
	{
		System.out.println("ServletContext Object Initialized...");
	}
	
	public void contextDestroyed(ServletContextEvent sce)
	{
		System.out.println("ServletContext Object Destroyed...");
	}
}
