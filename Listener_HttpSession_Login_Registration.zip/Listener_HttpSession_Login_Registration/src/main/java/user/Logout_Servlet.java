package user;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import javax.servlet.*;

@SuppressWarnings("serial")
@WebServlet("/LogOut")
public class Logout_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		HttpSession hs=req.getSession(false);
		
		if(hs==null)
			pw.println("Session Expired...");
		else
		{
			RegistrationBean rb=(RegistrationBean)hs.getAttribute("RegistrationBean");
			hs.invalidate();	//Session Destroyed
			pw.println(rb.getFname()+"&nbsp;"+rb.getLname()+" Logout Successfully....<br>");
		}
		
		RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
		rd.include(req, res);

	}
}
