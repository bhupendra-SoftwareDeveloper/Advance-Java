package user;
import javax.servlet.*;
import javax.servlet.annotation.*;

@WebListener
public class ServletRequest_Listener implements ServletRequestListener
{
	public void requestInitialized(ServletRequestEvent sre)
	{
		System.out.println("ServletRequest Object Initialized...");
	}
	
	public void requestDestroyed(ServletRequestEvent sre)
	{
		System.out.println("ServletRequest Object Destroyed...");
	}
}
