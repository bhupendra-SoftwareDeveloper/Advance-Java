package user;
import java.sql.*;
import javax.servlet.http.*;

public class LoginDAO
{
	private RegistrationBean rb;
	
	public RegistrationBean checkLogin(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM USERREG45 WHERE UNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("uname"));
			ps.setString(2, req.getParameter("pass"));
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				rb=new RegistrationBean();
				rb.setUname(rs.getString(1));
				rb.setPass(rs.getString(2));
				rb.setFname(rs.getString(3));
				rb.setLname(rs.getString(4));
				rb.setAddress(rs.getString(5));
				rb.setEmail(rs.getString(6));
				rb.setPhone_no(rs.getLong(7));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rb;
	}
}
