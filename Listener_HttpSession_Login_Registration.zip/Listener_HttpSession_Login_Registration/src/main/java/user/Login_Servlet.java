package user;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/Userlogin")
public class Login_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException,ServletException
	{
		RegistrationBean rb=new LoginDAO().checkLogin(req);
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		if(rb==null)
		{
			pw.println("Invalid UserName Or PassWord!!!");
			RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
			rd.include(req, res);
		}
		else
		{
			HttpSession hs=req.getSession();	//Creating Session
			hs.setAttribute("RegistrationBean",rb);	//Adding attribute to the session
			pw.println("Welcome "+rb.getFname()+"&nbsp;"+rb.getLname()+"<br>");
			RequestDispatcher rd=req.getRequestDispatcher("Link.html");
			rd.include(req, res);
		}
		
	}
}
