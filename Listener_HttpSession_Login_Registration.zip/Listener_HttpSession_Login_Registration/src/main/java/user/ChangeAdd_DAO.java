package user;
import java.sql.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
public class ChangeAdd_DAO extends HttpServlet
{
	int k;
	int change(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("UPDATE USERREG45 SET ADDRESS=? WHERE UNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("newadd"));
			ps.setString(2, req.getParameter("uname"));
			ps.setString(3, req.getParameter("pass"));
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
	}
}
