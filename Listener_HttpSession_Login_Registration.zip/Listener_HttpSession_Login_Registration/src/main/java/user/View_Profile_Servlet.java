package user;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
@SuppressWarnings("serial")
@WebServlet("/ViewProfile")
public class View_Profile_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException
	{ 
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		HttpSession hs=req.getSession(false);
		
		if(hs==null)
		{
			pw.println("Session Expired...");
			RequestDispatcher rd=req.getRequestDispatcher("UserLogin.html");
			rd.include(req, res);
		}
		else
		{
			RegistrationBean rb=(RegistrationBean)hs.getAttribute("RegistrationBean");
			pw.println("Page of "+rb.getFname()+"&nbsp;"+rb.getLname()+"<br>");
			
			pw.println("<br>");
			pw.println("<table><tr><th>UserName</th><th> </th><th>First Name</th><th> </th><th>Last Name</th><th> </th><th>Email Id</th><th> </th><th>Address</th><th> </th><th>Phone Number</th></tr>");
			
			pw.println("<tr align='center'><td>"+rb.getUname()+"</td><td> </td><td>"+rb.getFname()+"</td><td> </td><td>"+rb.getLname()+"</td><td> </td><td>"+
			rb.getEmail()+"</td><td> </td><td>"+rb.getAddress()+"</td><td> </td><td>"+rb.getPhone_no()+"</td></tr></table>");
			
			RequestDispatcher rd=req.getRequestDispatcher("Link.html");
			rd.include(req, res);
		}
	}
		
}


