package user;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebListener
public class HttpSession_Listener implements HttpSessionListener
{
	public void sessionCreated(HttpSessionEvent hse)
	{
		System.out.println("HttpSession Object Created...");
	}
	public void sessionDestroyed(HttpSessionEvent hse)
	{
		System.out.println("HttpSession Object Destroyed...");
	}
	public void attributeAdded(HttpSessionEvent hse)
	{
		System.out.println("Attribute Added to the Session...");
	}
	public void attributeRemoved(HttpSessionEvent hse)
	{
		System.out.println("Attribute Removed to the Session...");	
	}
}
