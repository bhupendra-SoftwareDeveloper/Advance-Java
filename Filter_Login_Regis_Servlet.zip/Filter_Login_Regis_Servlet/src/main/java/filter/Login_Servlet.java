package filter;
import javax.servlet.*;
import javax.servlet.annotation.*;
import java.io.*;
import javax.servlet.http.*;

@SuppressWarnings("serial")
@WebServlet("/login")
public class Login_Servlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter  pw=res.getWriter();
		res.setContentType("text/html");
		String name=(String)req.getAttribute("fname");
		
		pw.println("Login Successfully....<br>Welcome "+name);
	}
}
