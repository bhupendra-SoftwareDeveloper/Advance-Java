package filter;
import java.sql.*;
import javax.servlet.*;

public class LoginDAO
{
	private String fname;
	
	public String checkLogin(ServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM USERREG45 WHERE UNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("uname"));
			ps.setString(2, req.getParameter("pass"));
			
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				fname=rs.getString(3);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return fname;
	}
}
