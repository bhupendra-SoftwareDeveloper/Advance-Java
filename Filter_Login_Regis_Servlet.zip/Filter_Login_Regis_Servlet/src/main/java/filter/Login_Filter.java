package filter;
import java.io.*;
import javax.servlet.annotation.*;
import javax.servlet.*;

@WebFilter("/login")
public class Login_Filter implements Filter
{
	public void doFilter(ServletRequest req,ServletResponse res, FilterChain chain)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String fName=new LoginDAO().checkLogin(req);
		
		if(fName==null)
		{
			pw.println("Invalid Inputs!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Login.html");
			rd.include(req, res);
		}
		else
		{
			req.setAttribute("fname", fName);
			chain.doFilter(req, res);
		}
	}
}
