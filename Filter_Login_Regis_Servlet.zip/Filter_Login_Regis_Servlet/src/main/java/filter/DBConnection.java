package filter;
import java.sql.*;

public class DBConnection
{
	private static Connection con;
	
	static
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	static Connection getCon()
	{
		return con;
	}
}
