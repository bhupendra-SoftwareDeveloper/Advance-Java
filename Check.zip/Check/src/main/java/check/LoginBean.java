package check;

import java.io.Serializable;
@SuppressWarnings("serial")
public class LoginBean implements Serializable
{
	private String uname,pass;
	
	public LoginBean()
	{
		
	}

	protected String getUname() {
		return uname;
	}

	protected void setUname(String uname) {
		this.uname = uname;
	}

	protected String getPass() {
		return pass;
	}

	protected void setPass(String pass) {
		this.pass = pass;
	}
	
}
