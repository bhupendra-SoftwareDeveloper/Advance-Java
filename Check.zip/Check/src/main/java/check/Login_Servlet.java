package check;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;
import javax.servlet.*;

@SuppressWarnings("serial")
@WebServlet("/ulogin")
public class Login_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		 LoginBean lb=LoginDAO.check(req);
		 
		if(lb==null) {
			pw.println("Invalid user input!!!");
			RequestDispatcher rd=req.getRequestDispatcher("Login.html");
			rd.include(req,res);
		}
		else
		{
			Cookie ck=new Cookie("UNAME",lb.getUname());
			res.addCookie(ck);
			pw.println("Welcome to the page....");
			RequestDispatcher rd=req.getRequestDispatcher("link.html");
			rd.include(req,res);
		}
	}
}
