package check;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;

@SuppressWarnings("serial")
@WebServlet("/logout")
public class Logout_Servlet extends HttpServlet
{
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		Cookie c[]=req.getCookies();
		
		if(c==null)pw.println("Session Expired....");
		else
		{
			c[0].getValue();
			c[0].setMaxAge(0);
			pw.println("Logged out....");
		}
		RequestDispatcher rd=req.getRequestDispatcher("Login.html");
		rd.include(req, res);
	}
}
