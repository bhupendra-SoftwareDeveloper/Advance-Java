package check;
import java.sql.*;
import javax.servlet.http.*;

public class LoginDAO
{
	static LoginBean lb;
	
	static LoginBean check(HttpServletRequest req)
	{
		try
		{
			Connection con=DBConnection.getCon();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM LOGIN WHERE UNAME=? AND PWORD=?");
			ps.setString(1, req.getParameter("user"));
			ps.setString(2, req.getParameter("pass"));
			ResultSet rs=ps.executeQuery();
			System.out.println(rs.next());
			while(rs.next())
			{
				lb=new LoginBean();
				lb.setUname(rs.getString(1));
				lb.setPass(rs.getString(2));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return lb;
	}
}
